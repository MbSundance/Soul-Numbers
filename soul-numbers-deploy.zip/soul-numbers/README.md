# ☽ Soul Numbers

**Numerology · Biorhythm · AI Oracle Readings**

## Deploy to Netlify

1. Push this folder to a GitHub repo
2. Connect the repo to Netlify (netlify.com → Add new site → Import from Git)
3. Add these environment variables in **Netlify → Site Settings → Environment Variables**:

| Variable | Value |
|---|---|
| `STRIPE_SECRET_KEY` | `sk_live_...` (from Stripe Dashboard → Developers → API Keys) |
| `STRIPE_PRICE_ID` | `price_...` (from Stripe Dashboard → Product Catalog → your product) |

4. Deploy! Netlify auto-installs dependencies and wires up the functions.

## Local development

```bash
npm install -g netlify-cli
npm install
netlify dev
```

Then open http://localhost:8888

## Stripe setup

1. Create account at stripe.com
2. Add product: "Soul Numbers — Oracle Reading", $2.99 one-time
3. Copy the Price ID → paste as STRIPE_PRICE_ID env var
4. Copy Secret Key → paste as STRIPE_SECRET_KEY env var

Never commit your secret key to Git. Use env vars only.

## Tech stack

- Vanilla HTML/CSS/JS — zero dependencies on the frontend
- Netlify Functions (Node.js) — serverless Stripe checkout
- Claude API — AI oracle readings
- Stripe — payments

